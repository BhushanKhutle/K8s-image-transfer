import { NodeSSH } from 'node-ssh';
import { NodeConfig, SshConfig } from '../types';
import db from '../db/database';

export class SshService {
  private connections: Map<string, NodeSSH> = new Map();

  private getNodeConfig(nodeName: string): NodeConfig | null {
    const row = db.prepare(`
      SELECT id, node_name, host, port, username, auth_type, password, private_key, passphrase
      FROM node_configs WHERE node_name = ?
    `).get(nodeName) as any;

    if (!row) return null;

    return {
      id: row.id,
      nodeName: row.node_name,
      host: row.host,
      port: row.port,
      username: row.username,
      authType: row.auth_type,
      password: row.password,
      privateKey: row.private_key,
      passphrase: row.passphrase,
    };
  }

  async connect(nodeName: string): Promise<NodeSSH> {
    const config = this.getNodeConfig(nodeName);
    if (!config) {
      throw new Error(`No SSH configuration found for node: ${nodeName}`);
    }

    const ssh = new NodeSSH();
    const sshConfig: any = {
      host: config.host,
      port: config.port,
      username: config.username,
      readyTimeout: parseInt(process.env.SSH_TIMEOUT || '30000'),
    };

    if (config.authType === 'password' && config.password) {
      sshConfig.password = config.password;
    } else if (config.authType === 'privateKey' && config.privateKey) {
      sshConfig.privateKey = config.privateKey;
      if (config.passphrase) sshConfig.passphrase = config.passphrase;
    }

    await ssh.connect(sshConfig);
    return ssh;
  }

  async executeCommand(nodeName: string, command: string): Promise<{ stdout: string; stderr: string; code: number }> {
    const ssh = await this.connect(nodeName);
    try {
      const result = await ssh.execCommand(command);
      return {
        stdout: result.stdout,
        stderr: result.stderr,
        code: result.code ?? 0,
      };
    } finally {
      ssh.dispose();
    }
  }

  async testConnection(nodeName: string): Promise<{ success: boolean; error?: string }> {
    try {
      const result = await this.executeCommand(nodeName, 'echo "connected"');
      return { success: result.code === 0 };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  async getDockerImages(nodeName: string): Promise<string[]> {
    const result = await this.executeCommand(
      nodeName,
      'docker images --format "{{.Repository}}:{{.Tag}}" 2>/dev/null || crictl images --no-trunc 2>/dev/null | tail -n +2 | awk \'{print $1":"$2}\''
    );

    if (result.code !== 0) {
      throw new Error(`Failed to fetch images from ${nodeName}: ${result.stderr}`);
    }

    return result.stdout
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.includes('<none>'));
  }

  async transferImage(
    imageName: string,
    sourceNode: string,
    destNode: string,
    onProgress?: (msg: string) => void
  ): Promise<void> {
    const sourceConfig = this.getNodeConfig(sourceNode);
    const destConfig = this.getNodeConfig(destNode);

    if (!sourceConfig) throw new Error(`No config for source node: ${sourceNode}`);
    if (!destConfig) throw new Error(`No config for destination node: ${destNode}`);

    onProgress?.(`Connecting to source node ${sourceNode}...`);
    const sourceSsh = await this.connect(sourceNode);

    onProgress?.(`Connecting to destination node ${destNode}...`);
    const destSsh = await this.connect(destNode);

    try {
      onProgress?.(`Starting docker save on ${sourceNode}...`);

      // Use pipe-based transfer: docker save on source, pipe via buffer, docker load on dest
      // We use exec with piped streams for memory-efficient transfer
      const saveResult = await sourceSsh.execCommand(`docker save ${imageName} | gzip`, {
        execOptions: { maxBuffer: 1024 * 1024 * 1024 }, // 1GB buffer
      });

      if (saveResult.code !== 0) {
        throw new Error(`docker save failed on ${sourceNode}: ${saveResult.stderr}`);
      }

      onProgress?.(`Transferring image data to ${destNode}...`);

      // Pipe the gzipped image data to destination
      const loadResult = await destSsh.execCommand('docker load', {
        stdin: saveResult.stdout,
      });

      if (loadResult.code !== 0) {
        throw new Error(`docker load failed on ${destNode}: ${loadResult.stderr}`);
      }

      onProgress?.(`Image transferred successfully to ${destNode}`);
    } finally {
      sourceSsh.dispose();
      destSsh.dispose();
    }
  }

  async transferImageViaRelay(
    imageName: string,
    sourceNode: string,
    destNode: string,
    onProgress?: (msg: string) => void
  ): Promise<void> {
    const sourceConfig = this.getNodeConfig(sourceNode);
    const destConfig = this.getNodeConfig(destNode);

    if (!sourceConfig) throw new Error(`No config for source node: ${sourceNode}`);
    if (!destConfig) throw new Error(`No config for destination node: ${destNode}`);

    onProgress?.(`Saving image from ${sourceNode}...`);

    // Step 1: Save image on source to temp file
    const tmpFile = `/tmp/k8s-transfer-${Date.now()}.tar.gz`;
    const sourceSsh = await this.connect(sourceNode);

    try {
      const saveResult = await sourceSsh.execCommand(
        `docker save ${imageName} | gzip > ${tmpFile} && echo "SAVED"`
      );

      if (!saveResult.stdout.includes('SAVED')) {
        throw new Error(`Failed to save image on ${sourceNode}: ${saveResult.stderr}`);
      }

      onProgress?.(`Transferring image archive to ${destNode}...`);

      // Step 2: SCP from source to dest
      const destAuth = destConfig.authType === 'password'
        ? `-o StrictHostKeyChecking=no`
        : `-i ${destConfig.privateKey} -o StrictHostKeyChecking=no`;

      const scpCmd = `scp ${destAuth} -P ${destConfig.port} ${tmpFile} ${destConfig.username}@${destConfig.host}:${tmpFile}`;
      const scpResult = await sourceSsh.execCommand(scpCmd);

      if (scpResult.code !== 0) {
        throw new Error(`SCP failed: ${scpResult.stderr}`);
      }

      onProgress?.(`Loading image on ${destNode}...`);

      // Step 3: Load on destination
      const destSsh = await this.connect(destNode);
      try {
        const loadResult = await destSsh.execCommand(
          `docker load < ${tmpFile} && rm -f ${tmpFile}`
        );

        if (loadResult.code !== 0) {
          throw new Error(`docker load failed on ${destNode}: ${loadResult.stderr}`);
        }
      } finally {
        destSsh.dispose();
      }

      onProgress?.(`Image loaded on ${destNode} successfully`);

    } finally {
      // Cleanup temp file on source
      await sourceSsh.execCommand(`rm -f ${tmpFile}`).catch(() => {});
      sourceSsh.dispose();
    }
  }
}

export const sshService = new SshService();
